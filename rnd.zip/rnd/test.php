<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="site.css">
    <link rel="stylesheet" type="text/css" href="button.css">

</head>
<body>

    <div class="row">
        <div class="column">
            <h1>The textarea readonly attribute</h1>

            <textarea rows="20" cols="70">
            At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies.
            </textarea>

        </div>
        <div class="column">
            <h1>The textarea readonly attribute</h1>

            <textarea rows="20" cols="70" readonly>
            At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies.
            </textarea>

        </div>
    </div>

    <!-- <div id="list">
        <p><iframe src="t.txt" frameborder="0" height="100"
            width="95%"></iframe></p>
      </div> -->

      <!-- <form method="post"> 
        <input type="submit" name="button1"
                class="button" value="Button1" /> 
    </form>  -->


<?php
        if(array_key_exists('button1', $_POST)) { 
            button1(); 
        } 
        else if(array_key_exists('button2', $_POST)) { 
            button2(); 
        } 
        function button1() { 
          
            $command = escapeshellcmd('python /var/www/html/rnd/latest.py');
            $output = shell_exec($command);
            alert("hi");
            echo $output;

        } 
        function button2() { 
            echo "This is Button2 that is selected"; 
        } 
    ?> 

<script>
function myFunction() {
    exec('python /var/www/html/rnd/latest.py');
  
}   

<script>
function myFunction() {
    exec('perl  fnames.pl');
  
}

</script>



// <?php
// if(array_key_exists('button1', $_POST)) { 
//     button1(); 
// } 
// else if(array_key_exists('button2', $_POST)) { 
//     button2(); 
// } 
// function button1() { 
//     echo "This is Button1 that is selected"; 
// } 
// function button2() { 
//     echo "This is Button2 that is selected"; 
// } 
// ?> 

<form method="post"> 
<input type="submit" name="button1"
        class="button" value="Button1" /> 
  
<input type="submit" name="button2"
        class="button" value="Button2" /> 
</form> 
</head> 
<!-- 
<script> 
    // Requiring fs module in which  
    // readFile function is defined. 
    const fs = require('fs') 
      
    fs.readFile('t.txt', (err, data) => { 
        if (err) throw err; 
      
        alert(data.toString());
        console.log(data.toString()); 
    }) 
    </script>  -->


</body>
</html>