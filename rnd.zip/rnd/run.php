<?php
$command = escapeshellcmd('python /var/www/html/rnd/aditya/Aditya/aj.py');
$output = shell_exec($command);
echo $output;
?>