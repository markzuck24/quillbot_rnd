<?php
// $command = escapeshellcmd('python /var/www/html/rnd/latest.py');
// $output = shell_exec($command);
// echo $output;

$command = escapeshellcmd('perl blu.pl /var/www/html/rnd/r.txt < /var/www/html/rnd/h.txt ');
    $output = shell_exec($command);

// $command = escapeshellcmd('perl /var/www/html/rnd/fnames.pl');
// $output = shell_exec($command);
echo $output;

// $command = escapeshellcmd('perl /var/www/html/rnd/fnames.pl');
// $output = shell_exec($command);
// echo $output;



//   $fn = fopen("/var/www/html/rnd/fname.txt","r");
  
//   while(! feof($fn))  {
//     $result = fgets($fn);
//     strval($result);
//     //echo $result;
//     $command = escapeshellcmd('perl blu.pl /var/www/html/rnd/p.txt < /var/www/html/rnd/p.txt');
//     $output = shell_exec($command);
//     //echo $result;
//     echo "\n\n";
//   }

//   fclose($fn);


?>